module.exports = {
sessionSecret: 'developmentSessionSecret'
};